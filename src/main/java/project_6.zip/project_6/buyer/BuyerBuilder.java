package project_6.buyer;

import project_6.products.Product;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("unused")
public class BuyerBuilder {

    private double capital;
    private final Map<Integer, Product> shoppingList;
    private int age;

    public BuyerBuilder(HashMap<Integer, Product> shoppingList) {
        this.shoppingList = shoppingList;
    }

    public BuyerBuilder setCapital(double capital) {
        this.capital = capital;
        return this;
    }

    public BuyerBuilder setAge(int age) {
        this.age = age;
        return this;
    }

    @SuppressWarnings("UnusedReturnValue")
    private BuyerBuilder addProduct(Product product) {
        if (shoppingList.containsKey(product.getSkuNumber())) {
            addProduct(product.getSkuNumber());
        } else {
            shoppingList.put(product.getSkuNumber(), product);
        }
        return this;
    }

    private void addProduct(int skuNumber) {
        if (shoppingList.containsKey(skuNumber)) {
            var pos = shoppingList.get(skuNumber);
            pos.setAmount(pos.getAmount() + 1);
        }
    }

    public BuyerBuilder addAll(Class<? extends Product> clazz, int size, Object... args) {
        Product product; //объявление
        try {
            product = clazz.getConstructor //ищем в переданном классе конструктор с параметрами args
                (
                    //это стрим апи (stream API) апи для работы с последовтаельностями
                    Arrays.stream(args).
                        map(Object::getClass). //мэпим каждый аргумент в объект
                        toArray(Class[]::new) // переводим в массив классов
                ).
                newInstance(args); //создаем сущность (экземпляр)
        } catch (Exception ex) {
            throw new IllegalArgumentException
                (clazz + " has no public constructor with " + args.length + " args");
        }

        //создаем нужный продукт нужное количество раз
        for (int i = 0; i < size; i++) {
            addProduct(product);
        }
        return this;
    }

    public Buyer build() {
        return new Buyer(capital, age, (HashMap<Integer, Product>) shoppingList, 1000);
    }
}
