package project_6.misc;

import project_6.products.Product;

public class Position extends Product {
    private int amount = 0;
    private Class<project_6.products.Product> clazz;

    public Position(double price, String name, int skuNumber, double weight, int amount) {
        super(price, name, skuNumber, weight, amount);
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getAmount() {
        return amount;
    }

    public Class<project_6.products.Product> getClazz() {
        return clazz;
    }
}
