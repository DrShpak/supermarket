package project_6.products;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Objects;

public abstract class Product {
    private Double price;
    private final String name;
    private int skuNumber;
    private final double weight;
    private int amount;
    private int calories;
    private final Deque<Double> prices = new ArrayDeque<>(); //очередь
    //todo придумать тип для срока годности

    protected Product(double price, String name, int skuNumber, double weight, int amount) {
        this.price = price;
        this.name = name;
        this.skuNumber = skuNumber;
        this.weight = weight;
        this.amount = amount;
    }

    Product(double price, String name, int skuNumber, double weight, int amount, int calories) {
        this.price = price;
        this.name = name;
        this.skuNumber = skuNumber;
        this.weight = weight;
        this.amount = amount;
        this.calories = calories;
    }

    //todo пофиксить баг
    public boolean isSale() {
        return this.price < this.prices.getLast();
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public Deque<Double> getPrices() {
        return prices;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getSkuNumber() {
        return skuNumber;
    }

    public void setSkuNumber(int skuNumber) {
        this.skuNumber = skuNumber;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getCalories() {
        return calories;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Product)) return false;
        Product product = (Product) o;
        return Objects.equals(name, product.name) &&
                this.getClass().equals(product.getClass()); //или instanceof
    }

    public boolean equals(int skuNumber) {
        return this.skuNumber == skuNumber;
    }
}
