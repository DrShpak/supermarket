package project_6.products;

class Technics extends Product {

    public Technics(double price, String name, int skuNumber, double weight, int amount) {
        super(price, name, skuNumber, weight, amount);
    }
}