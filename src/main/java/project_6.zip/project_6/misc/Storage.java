package project_6.misc;

import project_6.products.Product;

import java.util.*;

public class Storage {
    private static final Map<Integer, Product> products = new HashMap<>();
    private static final Map<Integer, Class<? extends Product>> products2 = new HashMap<>();

    public static Map<Integer, Class<? extends Product>> getProducts2() {
        return products2;
    }

    private static void addProduct(Product product) {
        if (products.containsKey(product.getSkuNumber())) {
            addProduct(product.getSkuNumber());
        } else {
            products.put(product.getSkuNumber(), product);
        }
    }

    private static void addProduct(int skuNumber) {
        if (products.containsKey(skuNumber)) {
            var pos = products.get(skuNumber);
            pos.setAmount(pos.getAmount() + 1);
        }
    }

    public static void addAll(Product... products) {
        Arrays.stream(products).
            forEach(Storage::addProduct);
    }

    public static void delItem(int skuNumber) {
        var curr = products.get(skuNumber);
        curr.setAmount(curr.getAmount() - 1);
    }

    public static int getResidue(int skuNumber) {
        return products.get(skuNumber).getAmount();
    }

    public static void removeProduct(int skuNumber) {
        products.remove(skuNumber);
    }

    public static Map<Integer, Product> getProducts() {
        return products;
    }

    public boolean isEmpty() {
        return products.isEmpty();
    }

    public static boolean isProductExist(int skuNumber) {
        return products.containsKey(skuNumber);
    }

    //    private static List<Product> products = new ArrayList<>(); //все продукты в хранилище
//    public static void addProduct(Product product) {
//        setSkuNumber(product);
//        products.add(product);
//    }
//
//    public static void addAll(Product... arrProduct) {
//        Arrays.stream(arrProduct).forEach(Storage::setSkuNumber);
//        products.addAll(Arrays.stream(arrProduct).collect(Collectors.toList()));
//    }
//
//
//    private static void setSkuNumber(Product product) {
//        if (isProductExist(product.getName())) {
//            var equal = products.stream().
//                    filter(product1 -> product1.equals(product)).
//                    findAny();
//            equal.ifPresent(product1 -> product.setSkuNumber(product1.getSkuNumber()));
//        } else {
//            product.setSkuNumber(new Random().nextInt(100));
//        }
//    }
//
//    public static void removeProduct(Product product) {
//        products.remove(product);
//    }
//
//    public static List<Product> getProducts() {
//        return products;
//    }
//
//    public boolean isEmpty() {
//        return products.isEmpty();
//    }
//
//    public static boolean isProductExist(int SKUnumber) {
//        return products.stream().
//                anyMatch(product -> product.getSkuNumber() == SKUnumber);
//    }
//
//    //overload
//    public static boolean isProductExist(String name) {
//        return products.stream().
//                anyMatch(product -> product.getName().equals(name));
//    }
//
//    public static List<Product> getProducts(String name) {
//        return products.stream().
//                filter(product -> product.getName().equals(name)).
//                collect(Collectors.toList());
//    }
//
//    public static void setSale(int skuNumber, int sale) {
//        if (isProductExist(skuNumber)) {
//            products.stream().
//                    filter(product -> product.getSkuNumber() == skuNumber).
//                    collect(Collectors.toList()).
//                    forEach(product -> {
//                        product.getPrices().addLast(product.getPrice());
//                        product.setPrice(product.getPrice() - (product.getPrice() * sale / 100));
//                    });
//        }
//    }
}