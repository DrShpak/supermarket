package project_6.buyer;

import project_6.products.Alcohol;
import project_6.products.Cigarettes;
import project_6.products.Product;

import java.util.HashMap;
import java.util.Map;

public class Buyer {
    private double capital;
    private final Map<Integer, Product> shoppingList;
    private final int age;
    private int calories;

    public Buyer(double capital, int age, HashMap<Integer, Product> shoppingList, int calories) {
        this.capital = capital;
        this.age = age;
        this.shoppingList = shoppingList;
        this.calories = calories;
    }

    public <T extends Product> boolean isAdult(T product) {
        if (product.getClass().equals(Alcohol.class) || product.getClass().equals(Cigarettes.class)) {
            try {
                /*
                берем поле age и делаем его октрытым (по умолчанию он private)
                таким образом мы разрешаем работу с этим полем, на время проведения операции
                getDeclaredField вернет поле со всеми модификаторами (даже private and protected)
                 */
                var field = product.getClass().getDeclaredField("age");
                field.setAccessible(true); // открываем поле age
                var age = (int) field.get(product);
                return capital >= product.getPrice() && this.age >= age;
            } catch (IllegalAccessException | NoSuchFieldException e) {
                System.out.println("К сожалению, Вы не достигли нужного возраста!");
                return false;
            }
        } else {
            return capital >= product.getPrice();
        }
    }

    public boolean canBuy(Product product) {
        if (this.calories >= product.getCalories())
            return true;
        System.out.println("Продукт " + product.getName() + " содержит слишком много калорий для Вас!");
        return false;
    }

    public void delItem(int skuNumber) {
        var curr = shoppingList.get(skuNumber);
        curr.setAmount(curr.getAmount() - 1);
    }

    public int getResidue(int skuNumber) {
        return shoppingList.get(skuNumber).getAmount();
    }

    public double getCapital() {
        return capital;
    }

    public void setCapital(double capital) {
        this.capital = capital;
    }

    public Map<Integer, Product> getShoppingList() {
        return shoppingList;
    }

    public void addProductToList(Product position) {
        shoppingList.put(position.getSkuNumber(), position);
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }
}
