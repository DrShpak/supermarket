package project_6.products;

import java.util.Date;

public class Alcohol extends Product implements IOverdue {
    private int age = 18;
    @SuppressWarnings("FieldCanBeLocal")
    private final Date endDate;

    public Alcohol(Double price, String name, int skuNumber, Date endDate, Double volume, int amount) {
        super(price, name, skuNumber, volume, amount);
        this.endDate = endDate;
    }

    @SuppressWarnings("unused")
    public boolean isAdult(int age) {
        return age >= this.age;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Alcohol)) return false;
        if (!super.equals(o)) return false;
        Alcohol alcohol = (Alcohol) o;
        return age == alcohol.age; /*&&
                Double.compare(alcohol.ge, volume) == 0;*/
    }
}
