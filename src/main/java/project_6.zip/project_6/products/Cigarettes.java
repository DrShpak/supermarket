package project_6.products;

import java.util.Date;

public class Cigarettes extends Product implements IOverdue {
    private int age = 18;
    @SuppressWarnings("FieldCanBeLocal")
    private final Date endDate;

    //конструктор
    public Cigarettes(Double price, String name, int skuNumber, Date endDate, double weight, int amount) {
        super(price, name, skuNumber, weight, amount);
        this.endDate = endDate;
    }
}
