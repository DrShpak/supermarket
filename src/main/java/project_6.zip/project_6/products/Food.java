package project_6.products;

import java.util.Date;

public class Food extends Product implements IOverdue {
    private final Date endDate;
//    private int calories;

    public Food(Double price, String name, int skuNumber, Date endDate, Double weight, int amount) {
        super(price, name, skuNumber, weight, amount);
        this.endDate = endDate;
    }

    public Food(Double price, String name, int skuNumber, Date endDate, Double weight, int amount, int calories) {
        super(price, name, skuNumber, weight, amount, calories);
        this.endDate = endDate;
    }
}
