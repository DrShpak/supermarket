package project_6.tradingFloor;

import project_6.buyer.Buyer;
import project_6.misc.Storage;
import project_6.products.Product;

import java.util.*;

public class TradingFloor {


    @SuppressWarnings("FieldCanBeLocal")
    private final int diff = (int) 8.76e7; //сутки в мс
    private final Scanner input = new Scanner(System.in);

    //todo добавить поддержку множества покупателей
    private final Buyer buyer;

    public TradingFloor(Buyer buyer) {
        this.buyer = buyer;
    }

    public void start() {
        //noinspection StatementWithEmptyBody
        while (workPeriod()) ;
    }

    @SuppressWarnings("SameReturnValue")
    private boolean workPeriod() {
        Date currentDate = new Date(0); //аргументом конструткора является кол-во мс прошедших с 1970г.
        Date endDate = new Date(currentDate.getTime() + 10 * diff);
        while (endDate.compareTo(currentDate) > 0) {
            System.out.println("\nТекущая дата: " + currentDate.toString());
            System.out.println("\nСделайте выбор: ");
            System.out.println("\n1. Показать список доступных товаров и сделать покупку.");
            System.out.println("\n2. Сделайте выбор: Сделать скидку на товар.");
            int code = input.nextInt();
            input.nextLine(); //skip line
            switch (code) {
                case 1:
                    makeBuy();
                    break;
                case 2:
                    makeSale();
                    break;
                default:
                    break;
            }
            currentDate.setTime(currentDate.getTime() + 2 * diff);
        }
        return false;
    }

    private void makeSale() {
        System.out.println("Список артикулов с кратким описанием товара:");
        printProducts();
        System.out.println("Введите скидку на товар в процентах(!!): ");
        var sale = input.nextInt();
        input.nextLine(); //skip
        changePrice(sale, parseProducts());
    }

    //todo проверить целесообразность расположение этого метода здесь
    private void changePrice(int sale, List<Product> products) {
        var listNums = new ArrayList<Integer>();
        products.forEach(x -> listNums.add(x.getSkuNumber()));
        Storage.getProducts().values().
            stream().
            filter(x -> listNums.contains(x.getSkuNumber())).
            forEach(x -> setSale(x.getSkuNumber(), sale));
//        for (Product product : products) {
//            if (Storage.isProductExist(product.getSkuNumber())) {
//                Storage.getProducts().values().
//                    stream().
//                    filter(x -> x.equals(product.getSkuNumber())).
//                    forEach(x -> {
//                        x.getPrices().addLast(x.getPrice());
//                        x.setPrice(x.getPrice() * sale / 100);
//                    });
//            } else {
//                System.out.println("Данного товара на складе нет!");
//            }
    }

    private static void setSale(int skuNumber, int sale) {
        var product = Storage.getProducts().get(skuNumber);
        product.getPrices().addLast(product.getPrice());
        product.setPrice(product.getPrice() * (100 - sale) / 100);
    }

    private void makeBuy() {
        System.out.println("Доступные товары на складе: ");
        //выводим список доступных товаров
        printProducts();
        System.out.println("\nТовары, которые есть в Вашем спсике покупок: ");
        int[] index = {0};
        buyer.getShoppingList().
            values().
            forEach(product -> System.out.println(++index[0] + ". "
                + "название: " + product.getName()
                + "; количество: " + product.getAmount()));
        System.out.println();
        System.out.println("Ваш капитал: " + buyer.getCapital() + " rub.");
        System.out.println("Осталось употребить калорий в сутки: " + buyer.getCalories());
        buy(buyer, parseProducts()); //покупаем
    }

    private void buy(Buyer buyer, List<Product> products) {
        for (Product product : products) {
            var skuNumber = product.getSkuNumber();
            if (!buyer.getShoppingList().containsKey(skuNumber)) {
                System.out.println("Товара " + product.getName() + " нет в Вашем списке покупок!");
            } else {
                if (buyer.isAdult(product) && buyer.canBuy(product) && Storage.getResidue(skuNumber) > 0) {
                    if (buyer.getResidue(skuNumber) - 1 > 0) {
                        buyer.delItem(skuNumber);
                    } else {
                        buyer.getShoppingList().remove(skuNumber);
                    }
                    buyer.setCalories(buyer.getCalories() - product.getCalories());
                    buyer.setCapital(buyer.getCapital() - product.getPrice());
                    Storage.delItem(skuNumber);
                    if (Storage.getResidue(skuNumber) <= 0) {
                        Storage.removeProduct(skuNumber);
                    }
                    System.out.println("Продукт " + product.getName() + " успешно приобретен!\n");
                } else {
                    System.out.println("Данный покупатель не может позволить себе продукт " + product.getName());
//                    System.out.println("Ваш капитал = " + buyer.getCapital() + "; Цена продукта " + product.getName() + " = " + product.getPrice());
                }
            }
        }
    }

    /**
     * @return продукты, которые нужны покупателю
     */
    private List<Product> parseProducts() {
        System.out.println("Сделайте свой выбор (один или несколько через запятую): ");
        var choose = input.nextLine();

        //парсим продукты: удаляем пробелы и разделяем строку по запятой
        //и получаем строковый массив из артикулов продуктов
        var nums = choose.replaceAll("\\s", "").split(",");
        var products = new ArrayList<Product>();
        for (String skuNumber : nums) {
            products.add(Storage.getProducts().get(Integer.parseInt(skuNumber)));
        }
        return products;
    }

    private void printProducts() {
        System.out.println("Список артикулов с кратким описанием товара:");
        int[] index = {0};
        Storage.getProducts().
            values().
            forEach(x -> System.out.println(++index[0] + ". "
                + "артикул: " + x.getSkuNumber() + "; "
                + x.getName() + "; "
                + x.getPrice() + " rub.; "
                + "содержит калорий: " + x.getCalories()
            ));
    }
}
