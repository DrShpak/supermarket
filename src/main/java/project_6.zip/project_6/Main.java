package project_6;

import project_6.buyer.Buyer;
import project_6.products.Cigarettes;
import project_6.products.Food;
import project_6.tradingFloor.TradingFloor;
import project_6.tradingFloor.TradingFloorBuilder;

import java.util.Date;
import java.util.HashMap;

class Main {

    public static void main(String[] args) {
        Buyer buyer1 = new Buyer(100, 16, new HashMap<>(), 1000);
        buyer1.addProductToList(new Cigarettes(13d, "LD", 100, new Date(), 20d, 1));
        buyer1.addProductToList(new Food(30d, "bread", 200, new Date(), 20d, 1));
        buyer1.addProductToList(new Food(130d, "milk", 101, new Date(), 20d, 1));

        TradingFloor floor = new TradingFloorBuilder().setDefaultStuffInStorage().build(buyer1);
        floor.start();
    }
}
