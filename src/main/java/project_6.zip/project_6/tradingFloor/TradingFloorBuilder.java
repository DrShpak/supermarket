package project_6.tradingFloor;

import project_6.buyer.Buyer;
import project_6.misc.Storage;
import project_6.products.Cigarettes;
import project_6.products.Food;

import java.util.Date;
import java.util.Random;

public class TradingFloorBuilder {

    //билдер, сразу махом добалвяем кучу продуктов
    public TradingFloorBuilder setDefaultStuffInStorage() {
        Storage.addAll(
            new Food(30d, "bread", 200, new Date(), 10.1, 10, 750),
            new Food(100d, "milk", 101, new Date(),0.150, 20, 800),
            new Cigarettes(10d, "Bond", new Random().nextInt(100), new Date(), 0.150, 15)
        );
        return this;
    }

    public TradingFloor build(Buyer buyer) {
        return new TradingFloor(buyer);
    }
}
